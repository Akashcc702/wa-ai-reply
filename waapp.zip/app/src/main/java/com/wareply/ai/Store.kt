package com.wareply.ai

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

const val DEFAULT_PERSONA =
    "You are a polite personal assistant replying to WhatsApp messages on behalf of the owner, who is busy right now. " +
    "Keep replies short, natural and friendly. Do not make promises, payments, appointments or share private information. " +
    "If asked who you are, say you are the owner's auto-reply assistant and the owner will reply personally soon."

object P {
    val DEF: Map<String, String> = mapOf(
        "enabled" to "0",
        "apiKey" to "",
        "model" to "gemini-flash-latest",
        "temperature" to "0.7",
        "maxTokens" to "2048",
        "maxWords" to "60",
        "mode" to "0",
        "fixedText" to "I'm busy right now, I will reply to you soon.",
        "fallback" to "1",
        "rules" to "",
        "ignoreKw" to "",
        "ownerName" to "",
        "persona" to DEFAULT_PERSONA,
        "lang" to "0",
        "customLang" to "",
        "prefix" to "",
        "suffix" to "",
        "scope" to "0",
        "whitelist" to "",
        "blacklist" to "",
        "groups" to "0",
        "pkgWa" to "1",
        "pkgBiz" to "1",
        "replyMedia" to "0",
        "delayMin" to "2",
        "delayMax" to "6",
        "cooldown" to "15",
        "maxPerHour" to "20",
        "schedOn" to "0",
        "schedFrom" to "9",
        "schedTo" to "18",
        "memOn" to "1",
        "memN" to "6",
        "logSkips" to "0"
    )

    private fun sp(c: Context) = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    fun get(c: Context, k: String): String = sp(c).getString(k, DEF[k] ?: "") ?: ""

    fun set(c: Context, k: String, v: String) {
        sp(c).edit().putString(k, v).apply()
    }

    fun on(c: Context, k: String): Boolean = get(c, k) == "1"

    fun int(c: Context, k: String): Int =
        get(c, k).trim().toIntOrNull() ?: (DEF[k]?.toIntOrNull() ?: 0)
}

object Mem {
    private fun sp(c: Context) = c.getSharedPreferences("mem", Context.MODE_PRIVATE)

    @Synchronized
    fun load(c: Context, who: String): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        try {
            val a = JSONArray(sp(c).getString(who, "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONArray(i)
                out.add(Pair(o.getString(0), o.getString(1)))
            }
        } catch (e: Exception) {
        }
        return out
    }

    @Synchronized
    fun add(c: Context, who: String, role: String, text: String) {
        val cur = ArrayList<Pair<String, String>>(load(c, who))
        cur.add(Pair(role, text))
        val max = maxOf(2, P.int(c, "memN") * 2)
        while (cur.size > max) cur.removeAt(0)
        val a = JSONArray()
        for (p in cur) {
            val item = JSONArray()
            item.put(p.first)
            item.put(p.second)
            a.put(item)
        }
        sp(c).edit().putString(who, a.toString()).apply()
    }

    fun clear(c: Context) {
        sp(c).edit().clear().apply()
    }
}

object L {
    private fun sp(c: Context) = c.getSharedPreferences("log", Context.MODE_PRIVATE)

    @Synchronized
    fun add(c: Context, who: String, inc: String, out: String, st: String) {
        val old = try {
            JSONArray(sp(c).getString("l", "[]"))
        } catch (e: Exception) {
            JSONArray()
        }
        val o = JSONObject()
        o.put("t", SimpleDateFormat("dd/MM HH:mm:ss", Locale.getDefault()).format(Date()))
        o.put("w", who)
        o.put("i", inc)
        o.put("o", out)
        o.put("s", st)
        val n = JSONArray()
        n.put(o)
        for (i in 0 until minOf(old.length(), 99)) n.put(old.get(i))
        sp(c).edit().putString("l", n.toString()).apply()
    }

    @Synchronized
    fun text(c: Context): String {
        val sb = StringBuilder()
        try {
            val a = JSONArray(sp(c).getString("l", "[]"))
            if (a.length() == 0) return "(no log yet)"
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                sb.append("[").append(o.optString("t")).append("] ").append(o.optString("w")).append("\n")
                if (o.optString("i").isNotEmpty()) sb.append("  IN : ").append(o.optString("i")).append("\n")
                if (o.optString("o").isNotEmpty()) sb.append("  OUT: ").append(o.optString("o")).append("\n")
                sb.append("  STATUS: ").append(o.optString("s")).append("\n\n")
            }
        } catch (e: Exception) {
            sb.append("log error: ").append(e.message)
        }
        return sb.toString()
    }

    fun clear(c: Context) {
        sp(c).edit().clear().apply()
    }
}
