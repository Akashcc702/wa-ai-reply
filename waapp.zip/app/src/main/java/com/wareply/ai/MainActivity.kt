package com.wareply.ai

import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var root: LinearLayout
    private lateinit var statusTv: TextView
    private lateinit var personaEt: EditText

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "WA AI Reply"
        val sv = ScrollView(this)
        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(12), dp(16), dp(48))
        sv.addView(root)
        setContentView(sv)
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    // ---------------- helpers ----------------

    private fun header(t: String) {
        val v = TextView(this)
        v.text = t
        v.textSize = 18f
        v.setTypeface(null, Typeface.BOLD)
        v.setTextColor(0xFF075E54.toInt())
        v.setPadding(0, dp(26), 0, dp(4))
        root.addView(v)
    }

    private fun note(t: String) {
        val v = TextView(this)
        v.text = t
        v.textSize = 13f
        v.setTextColor(0xFF666666.toInt())
        v.setPadding(0, dp(2), 0, dp(4))
        root.addView(v)
    }

    private fun label(t: String) {
        val v = TextView(this)
        v.text = t
        v.textSize = 14f
        v.setPadding(0, dp(10), 0, 0)
        root.addView(v)
    }

    private fun sw(text: String, key: String, after: (() -> Unit)? = null) {
        val s = Switch(this)
        s.text = text
        s.textSize = 16f
        s.setPadding(0, dp(8), 0, dp(8))
        s.isChecked = P.on(this, key)
        s.setOnCheckedChangeListener { _, checked ->
            P.set(this@MainActivity, key, if (checked) "1" else "0")
            after?.invoke()
        }
        root.addView(s)
    }

    private fun field(
        text: String,
        key: String,
        lines: Int = 1,
        number: Boolean = false,
        hint: String = ""
    ): EditText {
        label(text)
        val e = EditText(this)
        e.setText(P.get(this, key))
        e.hint = hint
        if (number) {
            e.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        } else if (lines > 1) {
            e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            e.minLines = lines
            e.gravity = Gravity.TOP or Gravity.START
        } else {
            e.inputType = InputType.TYPE_CLASS_TEXT
        }
        e.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                P.set(this@MainActivity, key, s?.toString() ?: "")
            }
        })
        root.addView(e)
        return e
    }

    private fun spin(text: String, key: String, items: List<String>) {
        label(text)
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
        val cur = P.int(this, key)
        sp.setSelection(if (cur in items.indices) cur else 0)
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                P.set(this@MainActivity, key, position.toString())
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        root.addView(sp)
    }

    private fun btn(text: String, onClick: () -> Unit) {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.setOnClickListener { onClick() }
        root.addView(b)
    }

    private fun toast(m: String) {
        Toast.makeText(this, m, Toast.LENGTH_LONG).show()
    }

    private fun isListenerEnabled(): Boolean {
        val s = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        return s != null && s.contains(packageName)
    }

    private fun refreshStatus() {
        val acc = isListenerEnabled()
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        val bat = pm.isIgnoringBatteryOptimizations(packageName)
        val key = P.get(this, "apiKey").trim().isNotEmpty()
        statusTv.text = "Notification access: " + (if (acc) "\u2705 ON" else "\u274C OFF (tap button below)") +
                "\nBattery unrestricted: " + (if (bat) "\u2705 YES" else "\u26A0\uFE0F NO (tap button below)") +
                "\nGemini API key: " + (if (key) "\u2705 set" else "\u274C missing") +
                "\nAuto-reply: " + (if (P.on(this, "enabled")) "\u2705 ENABLED" else "\u23F8 OFF")
    }

    private fun openAppInfo() {
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
    }

    // ---------------- UI ----------------

    private fun buildUi() {
        val presetNames = listOf(
            "Choose a style preset\u2026",
            "Friendly assistant",
            "Professional / business",
            "Casual friend",
            "Very short replies"
        )
        val presets = listOf(
            DEFAULT_PERSONA,
            "You are a professional assistant replying to WhatsApp messages on behalf of a business owner. Be polite, formal and concise. " +
                    "Say the owner will respond as soon as possible. Do not quote prices, make commitments or share private details.",
            "You are replying on behalf of the owner in a casual, friendly, slightly humorous tone like a close friend would. " +
                    "Keep it light and short. Say the owner is busy and will reply soon. Never share private information or make promises.",
            "Reply in one short sentence only. Say the owner is busy and will reply soon. Answer nothing else."
        )

        // ---- status / master ----
        header("1. Status & permissions")
        statusTv = TextView(this)
        statusTv.textSize = 14f
        statusTv.setPadding(0, dp(4), 0, dp(8))
        root.addView(statusTv)
        sw("ENABLE AUTO-REPLY (master switch)", "enabled") { refreshStatus() }
        btn("1) Grant Notification access") {
            try {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            } catch (e: Exception) {
                toast("Open Settings > Notifications > Notification access manually")
            }
        }
        btn("2) Battery: set to Unrestricted") {
            try {
                startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
                )
            } catch (e: Exception) {
                try {
                    startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                } catch (e2: Exception) {
                    openAppInfo()
                }
            }
        }
        btn("3) Xiaomi/Redmi Autostart settings") {
            try {
                val i = Intent()
                i.component = ComponentName(
                    "com.miui.securitycenter",
                    "com.miui.permcenter.autostart.AutoStartManagementActivity"
                )
                startActivity(i)
            } catch (e: Exception) {
                toast("Could not open Autostart directly. Open Security app > Permissions > Autostart")
                openAppInfo()
            }
        }
        btn("App info (for 'Allow restricted settings')") { openAppInfo() }
        note(
            "If Notification access is greyed out: App info > top-right \u22EE menu > 'Allow restricted settings', then grant access again. " +
                    "Also lock this app in the Recents screen and keep WhatsApp notifications ON (not muted)."
        )
        btn("\uD83E\uDDEA Test Gemini now") {
            Thread {
                val r = try {
                    Gemini.reply(this@MainActivity, "Hi, who is this?", "Test", false, emptyList())
                } catch (e: Exception) {
                    "ERROR: " + e.message
                }
                runOnUiThread {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("Gemini test")
                        .setMessage(r)
                        .setPositiveButton("OK", null)
                        .show()
                }
            }.start()
        }
        btn("\uD83D\uDCDC View reply log") { startActivity(Intent(this, LogActivity::class.java)) }

        // ---- Gemini ----
        header("2. Gemini AI")
        field("Gemini API key", "apiKey", hint = "paste your key here")
        field("Model name", "model", hint = "gemini-2.5-flash")
        field("Creativity / temperature (0 - 2)", "temperature", number = true)
        field("Max output tokens (Kannada needs more, 400-800)", "maxTokens", number = true)
        field("Max words per reply", "maxWords", number = true)

        // ---- mode ----
        header("3. Reply mode")
        spin(
            "How to reply",
            "mode",
            listOf(
                "AI (keyword rules first, then Gemini)",
                "Fixed text only (no AI)",
                "Keyword rules only"
            )
        )
        field("Fixed text (used in fixed mode / as fallback)", "fixedText", lines = 2)
        sw("Send fixed text if AI fails or no rule matches", "fallback")
        field(
            "Keyword rules (one per line:  word1|word2 => reply)",
            "rules",
            lines = 4,
            hint = "price|rate => Price list: ...\nlocation => We are at ..."
        )
        field("Ignore messages containing (comma separated)", "ignoreKw", hint = "otp, bank, loan")

        // ---- persona ----
        header("4. Personality & language")
        field("Owner name (optional)", "ownerName")
        label("Style preset (fills the box below)")
        val ps = Spinner(this)
        ps.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, presetNames)
        ps.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (position > 0) personaEt.setText(presets[position - 1])
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        root.addView(ps)
        personaEt = field("AI instructions / persona (edit freely)", "persona", lines = 6)
        spin(
            "Reply language",
            "lang",
            listOf(
                "Same as incoming message",
                "Kannada (\u0C95\u0CA8\u0CCD\u0CA8\u0CA1)",
                "English",
                "Hindi",
                "Kanglish (Kannada in English letters)",
                "Custom (type below)"
            )
        )
        field("Custom language instruction", "customLang", hint = "e.g. Reply in Tamil")
        field("Text added BEFORE every reply", "prefix", hint = "\uD83E\uDD16 ")
        field("Text added AFTER every reply", "suffix", hint = " (auto-reply)")

        // ---- who ----
        header("5. Who to reply to")
        spin(
            "Reply scope",
            "scope",
            listOf("Everyone", "Only whitelist", "Everyone except blacklist")
        )
        field("Whitelist names (comma separated, as shown in WhatsApp)", "whitelist", lines = 2, hint = "Amma, Rahul")
        field("Blacklist names (comma separated)", "blacklist", lines = 2)
        sw("Reply in GROUP chats too (risky)", "groups")
        sw("Reply to photo / voice / video / sticker messages", "replyMedia")
        sw("WhatsApp (green)", "pkgWa")
        sw("WhatsApp Business", "pkgBiz")

        // ---- timing ----
        header("6. Timing & safety limits")
        field("Minimum delay before reply (seconds)", "delayMin", number = true)
        field("Maximum delay before reply (seconds)", "delayMax", number = true)
        field("Cooldown per person (seconds)", "cooldown", number = true)
        field("Max auto-replies per person per hour (0 = unlimited)", "maxPerHour", number = true)
        sw("Reply only during active hours", "schedOn")
        field("Active from hour (0-23)", "schedFrom", number = true)
        field("Active until hour (0-23)", "schedTo", number = true)

        // ---- memory ----
        header("7. Conversation memory")
        sw("Remember previous messages per person", "memOn")
        field("How many past exchanges to remember", "memN", number = true)
        btn("Clear all memory") {
            Mem.clear(this)
            toast("Memory cleared")
        }

        // ---- log ----
        header("8. Debug")
        sw("Also log skipped messages (for troubleshooting)", "logSkips")
        note("Tip: send a WhatsApp message from another number, then open the reply log to see what happened.")
    }
}
