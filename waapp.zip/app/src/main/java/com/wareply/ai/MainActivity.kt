package com.wareply.ai

import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var root: LinearLayout
    private lateinit var cur: LinearLayout
    private lateinit var statusTv: TextView
    private lateinit var personaEt: EditText

    // theme colors (set in onCreate according to light / dark mode)
    private var cBg = 0
    private var cCard = 0
    private var cStroke = 0
    private var cText = 0
    private var cSub = 0
    private var cAccent = 0
    private var cInput = 0
    private var cInputStroke = 0

    private val MATCH = LinearLayout.LayoutParams.MATCH_PARENT
    private val WRAP = LinearLayout.LayoutParams.WRAP_CONTENT

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun box(fill: Int, stroke: Int, radiusDp: Int, strokeDp: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(fill)
        g.cornerRadius = dp(radiusDp).toFloat()
        g.setStroke(dp(strokeDp), stroke)
        return g
    }

    private fun lp(topDp: Int): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(MATCH, WRAP)
        p.topMargin = dp(topDp)
        return p
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "WA AI Reply"
        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
                Configuration.UI_MODE_NIGHT_YES
        if (night) {
            cBg = 0xFF121212.toInt(); cCard = 0xFF1E1E1E.toInt(); cStroke = 0xFF3A3A3A.toInt()
            cText = 0xFFEDEDED.toInt(); cSub = 0xFFB0B0B0.toInt(); cAccent = 0xFF4FD1A5.toInt()
            cInput = 0xFF2A2A2A.toInt(); cInputStroke = 0xFF7A7A7A.toInt()
        } else {
            cBg = 0xFFF2F4F5.toInt(); cCard = 0xFFFFFFFF.toInt(); cStroke = 0xFFD0D5D8.toInt()
            cText = 0xFF1B1B1B.toInt(); cSub = 0xFF555555.toInt(); cAccent = 0xFF075E54.toInt()
            cInput = 0xFFF7F8F9.toInt(); cInputStroke = 0xFF8A9096.toInt()
        }

        val sv = ScrollView(this)
        sv.setBackgroundColor(cBg)
        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(14), dp(28), dp(14), dp(48))
        sv.addView(root)
        setContentView(sv)
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    // ---------------- helpers ----------------

    private fun appTitle() {
        val v = TextView(this)
        v.text = "WA AI Reply"
        v.textSize = 26f
        v.setTypeface(null, Typeface.BOLD)
        v.setTextColor(cText)
        root.addView(v)
        val s = TextView(this)
        s.text = "WhatsApp auto-reply powered by Gemini"
        s.textSize = 13f
        s.setTextColor(cSub)
        root.addView(s)
    }

    private fun card(titleText: String) {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(14), dp(12), dp(14), dp(14))
        c.background = box(cCard, cStroke, 14, 1)
        root.addView(c, lp(14))
        val t = TextView(this)
        t.text = titleText
        t.textSize = 18f
        t.setTypeface(null, Typeface.BOLD)
        t.setTextColor(cAccent)
        c.addView(t)
        cur = c
    }

    private fun note(t: String) {
        val v = TextView(this)
        v.text = t
        v.textSize = 13f
        v.setTextColor(cSub)
        v.setPadding(0, dp(6), 0, dp(2))
        cur.addView(v)
    }

    private fun label(t: String) {
        val v = TextView(this)
        v.text = t
        v.textSize = 14f
        v.setTextColor(cText)
        cur.addView(v, lp(12))
    }

    private fun sw(text: String, key: String, after: (() -> Unit)? = null) {
        val s = Switch(this)
        s.text = text
        s.textSize = 16f
        s.setTextColor(cText)
        s.setPadding(0, dp(8), 0, dp(8))
        s.isChecked = P.on(this, key)
        s.setOnCheckedChangeListener { _, checked ->
            P.set(this@MainActivity, key, if (checked) "1" else "0")
            after?.invoke()
        }
        cur.addView(s, lp(4))
    }

    private fun field(
        text: String,
        key: String,
        lines: Int = 1,
        number: Boolean = false,
        hint: String = ""
    ): EditText {
        label(text)
        val e = EditText(this)
        e.setText(P.get(this, key))
        e.hint = hint
        e.setTextColor(cText)
        e.setHintTextColor(cSub)
        e.textSize = 15f
        e.background = box(cInput, cInputStroke, 8, 2)
        e.setPadding(dp(12), dp(10), dp(12), dp(10))
        if (number) {
            e.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        } else if (lines > 1) {
            e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            e.minLines = lines
            e.gravity = Gravity.TOP or Gravity.START
        } else {
            e.inputType = InputType.TYPE_CLASS_TEXT
        }
        e.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                P.set(this@MainActivity, key, s?.toString() ?: "")
            }
        })
        cur.addView(e, lp(4))
        return e
    }

    private fun spinnerBox(sp: Spinner) {
        val wrap = LinearLayout(this)
        wrap.orientation = LinearLayout.VERTICAL
        wrap.background = box(cInput, cInputStroke, 8, 2)
        wrap.setPadding(dp(6), dp(2), dp(6), dp(2))
        wrap.addView(sp, LinearLayout.LayoutParams(MATCH, WRAP))
        cur.addView(wrap, lp(4))
    }

    private fun spin(text: String, key: String, items: List<String>) {
        label(text)
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
        val c = P.int(this, key)
        sp.setSelection(if (c in items.indices) c else 0)
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                P.set(this@MainActivity, key, position.toString())
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        spinnerBox(sp)
    }

    private fun btn(text: String, onClick: () -> Unit) {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.setTextColor(Color.WHITE)
        b.textSize = 15f
        b.background = box(cAccent, cAccent, 10, 1)
        b.setOnClickListener { onClick() }
        cur.addView(b, lp(8))
    }

    private fun toast(m: String) {
        Toast.makeText(this, m, Toast.LENGTH_LONG).show()
    }

    private fun showDialog(titleText: String, msg: String) {
        AlertDialog.Builder(this)
            .setTitle(titleText)
            .setMessage(msg)
            .setPositiveButton("OK", null)
            .show()
    }

    private fun isListenerEnabled(): Boolean {
        val s = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        return s != null && s.contains(packageName)
    }

    private fun refreshStatus() {
        val acc = isListenerEnabled()
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        val bat = pm.isIgnoringBatteryOptimizations(packageName)
        val key = P.get(this, "apiKey").trim().isNotEmpty()
        statusTv.text = "Notification access: " + (if (acc) "\u2705 ON" else "\u274C OFF (use button below)") +
                "\nBattery unrestricted: " + (if (bat) "\u2705 YES" else "\u26A0\uFE0F NO (use button below)") +
                "\nGemini API key: " + (if (key) "\u2705 set" else "\u274C missing") +
                "\nAuto-reply: " + (if (P.on(this, "enabled")) "\u2705 ENABLED" else "\u23F8 OFF")
    }

    private fun openAppInfo() {
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
    }

    // ---------------- UI ----------------

    private fun buildUi() {
        val presetNames = listOf(
            "1) CC AI (ChatGPT/Claude ಶೈಲಿ - Default)",
            "2) Akash's Assistant (ಆಕಾಶ್ ಸಹಾಯಕ)",
            "3) Directly as Akash (ಖುದ್ದು ಆಕಾಶ್)",
            "4) Custom Persona (ಕಸ್ಟಮ್ ಶೈಲಿ)"
        )
        val presets = listOf(
            PERSONA_CC_AI,
            PERSONA_ASSISTANT,
            PERSONA_AKASH,
            ""
        )

        appTitle()

        // ---- status / master ----
        card("1. Status & permissions")
        statusTv = TextView(this)
        statusTv.textSize = 14f
        statusTv.setTextColor(cText)
        statusTv.setPadding(0, dp(8), 0, dp(4))
        cur.addView(statusTv)
        sw("ENABLE AUTO-REPLY (master switch)", "enabled") { refreshStatus() }
        btn("1) Grant Notification access") {
            try {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            } catch (e: Exception) {
                toast("Open Settings > Notifications > Notification access manually")
            }
        }
        btn("2) Battery: set to Unrestricted") {
            try {
                startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
                )
            } catch (e: Exception) {
                try {
                    startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                } catch (e2: Exception) {
                    openAppInfo()
                }
            }
        }
        btn("3) Xiaomi / Redmi Autostart settings") {
            try {
                val i = Intent()
                i.component = ComponentName(
                    "com.miui.securitycenter",
                    "com.miui.permcenter.autostart.AutoStartManagementActivity"
                )
                startActivity(i)
            } catch (e: Exception) {
                toast("Could not open Autostart directly. Open Security app > Permissions > Autostart")
                openAppInfo()
            }
        }
        btn("App info (for 'Allow restricted settings')") { openAppInfo() }
        note(
            "If Notification access is greyed out: App info > top-right \u22EE menu > 'Allow restricted settings', then grant access again. " +
                    "Also lock this app in the Recents screen and keep WhatsApp notifications ON (not muted)."
        )
        btn("\uD83E\uDDEA Test Gemini now") {
            Thread {
                val r = try {
                    Gemini.reply(this@MainActivity, "Hi, who is this?", "Test", false, emptyList())
                } catch (e: Exception) {
                    "ERROR: " + e.message
                }
                runOnUiThread { showDialog("Gemini test", r) }
            }.start()
        }
        btn("\uD83D\uDCCB List available Gemini models") {
            Thread {
                val r = try {
                    Gemini.listModels(this@MainActivity)
                } catch (e: Exception) {
                    "ERROR: " + e.message
                }
                runOnUiThread { showDialog("Models for your key", r) }
            }.start()
        }
        btn("\uD83D\uDCDC View reply log") { startActivity(Intent(this, LogActivity::class.java)) }

        // ---- Gemini ----
        card("2. Gemini AI")
        field("Gemini API key", "apiKey", hint = "paste your key here")
        field("Primary Model name", "model", hint = "gemini-flash-lite-latest")
        note("⚡ Auto 5-Model Failover (1-3s fast replies):\ngemini-flash-lite-latest ➔ gemini-3.5-flash-lite ➔ gemini-3.1-flash-lite ➔ gemini-2.5-flash-lite ➔ gemini-3.5-flash.\nIf any model is busy/503/timeout, it rotates to the next one instantly!")
        field("Creativity / temperature (0 - 2)", "temperature", number = true)
        field("Max output tokens (keep 1000+ for Kannada)", "maxTokens", number = true)
        field("Max words per reply", "maxWords", number = true)

        // ---- mode ----
        card("3. Reply mode")
        spin(
            "How to reply",
            "mode",
            listOf(
                "AI (keyword rules first, then Gemini)",
                "Fixed text only (no AI)",
                "Keyword rules only"
            )
        )
        field("Fixed text (fixed mode / fallback)", "fixedText", lines = 2)
        sw("Send fixed text if AI fails or no rule matches", "fallback")
        field(
            "Keyword rules (one per line:  word1|word2 => reply)",
            "rules",
            lines = 4,
            hint = "price|rate => Price list: ...\nlocation => We are at ..."
        )
        field("Ignore messages containing (comma separated)", "ignoreKw", hint = "otp, bank, loan")

        // ---- persona ----
        card("4. Personality & language")
        field("Owner name (optional)", "ownerName")
        label("Style preset (fills the box below)")
        val ps = Spinner(this)
        ps.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, presetNames)
        val curPersona = P.get(this, "persona")
        val initialPos = when (curPersona) {
            PERSONA_CC_AI -> 0
            PERSONA_ASSISTANT -> 1
            PERSONA_AKASH -> 2
            else -> 3
        }
        ps.setSelection(initialPos)
        ps.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (position in 0..2) {
                    personaEt.setText(presets[position])
                } else if (position == 3) {
                    if (personaEt.text.toString() == PERSONA_CC_AI ||
                        personaEt.text.toString() == PERSONA_ASSISTANT ||
                        personaEt.text.toString() == PERSONA_AKASH) {
                        personaEt.setText("")
                    }
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        spinnerBox(ps)
        personaEt = field("AI instructions / persona (edit freely)", "persona", lines = 6)
        spin(
            "Reply language",
            "lang",
            listOf(
                "Same as incoming message",
                "Kannada (\u0C95\u0CA8\u0CCD\u0CA8\u0CA1)",
                "English",
                "Hindi",
                "Kanglish (Kannada in English letters)",
                "Custom (type below)"
            )
        )
        field("Custom language instruction", "customLang", hint = "e.g. Reply in Tamil")
        field("Text added BEFORE every reply", "prefix", hint = "\uD83E\uDD16 ")
        field("Text added AFTER every reply", "suffix", hint = " (auto-reply)")

        // ---- who ----
        card("5. Who to reply to")
        spin(
            "Reply scope",
            "scope",
            listOf("Everyone", "Only whitelist", "Everyone except blacklist")
        )
        field("Whitelist names (comma separated, as shown in WhatsApp)", "whitelist", lines = 2, hint = "Amma, Rahul")
        field("Blacklist names (comma separated)", "blacklist", lines = 2)
        sw("Reply in GROUP chats too (risky)", "groups")
        sw("Reply to photo / voice / video / sticker messages", "replyMedia")
        sw("WhatsApp (green)", "pkgWa")
        sw("WhatsApp Business", "pkgBiz")

        // ---- timing ----
        card("6. Timing & safety limits")
        field("Minimum delay before reply (seconds)", "delayMin", number = true)
        field("Maximum delay before reply (seconds)", "delayMax", number = true)
        field("Cooldown per person (seconds)", "cooldown", number = true)
        field("Max auto-replies per person per hour (0 = unlimited)", "maxPerHour", number = true)
        sw("Reply only during active hours", "schedOn")
        field("Active from hour (0-23)", "schedFrom", number = true)
        field("Active until hour (0-23)", "schedTo", number = true)

        // ---- memory ----
        card("7. Conversation memory")
        sw("Remember previous messages per person", "memOn")
        field("How many past exchanges to remember", "memN", number = true)
        btn("Clear all memory") {
            Mem.clear(this)
            toast("Memory cleared")
        }

        // ---- debug ----
        card("8. Debug")
        sw("Also log skipped messages (for troubleshooting)", "logSkips")
        note("Tip: send a WhatsApp message from another number, then open the reply log to see what happened.")
    }
}
