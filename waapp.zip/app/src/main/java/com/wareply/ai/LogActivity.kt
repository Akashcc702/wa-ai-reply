package com.wareply.ai

import android.app.Activity
import android.graphics.Typeface
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class LogActivity : Activity() {
    private lateinit var tv: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Reply log"
        val night = (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
                android.content.res.Configuration.UI_MODE_NIGHT_YES
        val pad = (14 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad * 2, pad, pad)
        root.setBackgroundColor(if (night) 0xFF121212.toInt() else 0xFFF2F4F5.toInt())

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val refresh = Button(this)
        refresh.text = "Refresh"
        refresh.setOnClickListener { load() }
        val clear = Button(this)
        clear.text = "Clear log"
        clear.setOnClickListener { L.clear(this); load() }
        row.addView(refresh)
        row.addView(clear)
        root.addView(row)

        tv = TextView(this)
        tv.typeface = Typeface.MONOSPACE
        tv.textSize = 12f
        tv.setTextColor(if (night) 0xFFEDEDED.toInt() else 0xFF1B1B1B.toInt())
        tv.setTextIsSelectable(true)
        val sv = ScrollView(this)
        sv.addView(tv)
        root.addView(sv)
        setContentView(root)
        load()
    }

    private fun load() {
        tv.text = L.text(this)
    }
}
