package com.wareply.ai

import android.app.Activity
import android.graphics.Typeface
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class LogActivity : Activity() {
    private lateinit var tv: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Reply log"
        val pad = (14 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad, pad, pad)

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val refresh = Button(this)
        refresh.text = "Refresh"
        refresh.setOnClickListener { load() }
        val clear = Button(this)
        clear.text = "Clear log"
        clear.setOnClickListener { L.clear(this); load() }
        row.addView(refresh)
        row.addView(clear)
        root.addView(row)

        tv = TextView(this)
        tv.typeface = Typeface.MONOSPACE
        tv.textSize = 12f
        tv.setTextIsSelectable(true)
        val sv = ScrollView(this)
        sv.addView(tv)
        root.addView(sv)
        setContentView(root)
        load()
    }

    private fun load() {
        tv.text = L.text(this)
    }
}
