package com.wareply.ai

import android.app.Notification
import android.app.RemoteInput
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.util.Calendar
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import kotlin.random.Random

class WaListenerService : NotificationListenerService() {

    private val pool = Executors.newFixedThreadPool(2)

    companion object {
        val lastTime = ConcurrentHashMap<String, Long>()
        val lastKey = ConcurrentHashMap<String, Long>()
        val lastReplyAt = ConcurrentHashMap<String, Long>()
        val hourly = ConcurrentHashMap<String, ArrayList<Long>>()
        val sentTexts = ArrayList<String>()

        private val SYSTEM_PARTS = listOf(
            "checking for new messages", "waiting for this message", "this message was deleted",
            "you deleted this message", "missed voice call", "missed video call", "incoming voice call",
            "incoming video call", "ongoing voice call", "ongoing video call", "whatsapp web",
            "backup in progress", "new messages"
        )
        private val MEDIA_STARTS = listOf(
            "\uD83D\uDCF7", "\uD83C\uDFA4", "\uD83C\uDFB5", "\uD83C\uDFA5", "\uD83D\uDCF9",
            "\uD83D\uDCCD", "\uD83D\uDCC4", "\uD83D\uDC64"
        )
        private val MEDIA_EXACT = setOf(
            "photo", "video", "sticker", "gif", "voice message", "audio", "document", "location", "contact"
        )
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        try {
            handle(sbn)
        } catch (e: Throwable) {
            L.add(applicationContext, "-", "", "", "ERROR: " + e.message)
        }
    }

    override fun onListenerDisconnected() {
        try {
            requestRebind(ComponentName(this, WaListenerService::class.java))
        } catch (e: Throwable) {
        }
    }

    private fun skip(c: Context, who: String, text: String, why: String) {
        if (P.on(c, "logSkips")) L.add(c, who, text, "", "skipped: $why")
    }

    private fun inSchedule(c: Context): Boolean {
        if (!P.on(c, "schedOn")) return true
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val from = P.int(c, "schedFrom")
        val to = P.int(c, "schedTo")
        if (from == to) return true
        return if (from < to) (h >= from && h < to) else (h >= from || h < to)
    }

    private fun nameMatch(list: String, who: String): Boolean {
        val w = who.lowercase()
        for (n in list.split(",", "\n")) {
            val t = n.trim().lowercase()
            if (t.isNotEmpty() && w.contains(t)) return true
        }
        return false
    }

    private fun handle(sbn: StatusBarNotification) {
        val c = applicationContext
        if (!P.on(c, "enabled")) return
        val pkg = sbn.packageName
        val allowed = (pkg == "com.whatsapp" && P.on(c, "pkgWa")) ||
                (pkg == "com.whatsapp.w4b" && P.on(c, "pkgBiz"))
        if (!allowed) return
        val n = sbn.notification ?: return
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        val ex = n.extras ?: return

        var title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim() ?: return
        title = title.replace(Regex("\\s*\\(\\d+ messages?\\)"), "").trim()
        if (title.isEmpty()) return
        val tl = title.lowercase()
        if (tl == "whatsapp" || tl == "whatsapp business") return

        var text = ""
        var msgTime = 0L
        val arr = ex.getParcelableArray("android.messages")
        if (arr != null && arr.isNotEmpty()) {
            val last = arr[arr.size - 1] as? Bundle
            if (last != null) {
                text = last.getCharSequence("text")?.toString() ?: ""
                msgTime = last.getLong("time", 0L)
            }
        }
        if (text.isEmpty()) text = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        text = text.trim()
        if (text.isEmpty()) return
        val txl = text.lowercase()

        // system / non-message notifications
        if (txl.length < 80) {
            for (s in SYSTEM_PARTS) if (txl.contains(s)) return
        }
        if (txl.startsWith("you: ")) return
        synchronized(sentTexts) {
            for (s in sentTexts) if (s == text) return
        }

        val isGroup = ex.getBoolean("android.isGroupConversation", false) ||
                ex.getCharSequence("android.conversationTitle") != null

        // de-duplicate (same message processed once)
        val keyWho = "$pkg|$title"
        val now = System.currentTimeMillis()
        if (msgTime > 0) {
            val prev = lastTime[keyWho] ?: 0L
            if (msgTime <= prev) return
            lastTime[keyWho] = msgTime
        } else {
            val k = "$keyWho|$txl"
            val pk = lastKey[k]
            if (pk != null && now - pk < 600000L) return
            lastKey[k] = now
        }

        if (isGroup && !P.on(c, "groups")) { skip(c, title, text, "group chat"); return }

        if (!inSchedule(c)) { skip(c, title, text, "outside active hours"); return }

        when (P.int(c, "scope")) {
            1 -> if (!nameMatch(P.get(c, "whitelist"), title)) { skip(c, title, text, "not in whitelist"); return }
            2 -> if (nameMatch(P.get(c, "blacklist"), title)) { skip(c, title, text, "in blacklist"); return }
        }

        val ign = P.get(c, "ignoreKw")
        for (k in ign.split(",", "\n")) {
            val t = k.trim().lowercase()
            if (t.isNotEmpty() && txl.contains(t)) { skip(c, title, text, "ignore keyword '$t'"); return }
        }

        if (!P.on(c, "replyMedia")) {
            for (m in MEDIA_STARTS) {
                if (txl.startsWith(m)) { skip(c, title, text, "media message"); return }
            }
            if (MEDIA_EXACT.contains(txl)) { skip(c, title, text, "media message"); return }
        }

        val cd = P.int(c, "cooldown") * 1000L
        val lr = lastReplyAt[keyWho] ?: 0L
        if (now - lr < cd) { skip(c, title, text, "cooldown"); return }

        val maxH = P.int(c, "maxPerHour")
        val list = hourly.getOrPut(keyWho) { ArrayList() }
        synchronized(list) {
            list.removeAll { now - it > 3600000L }
            if (maxH > 0 && list.size >= maxH) {
                skip(c, title, text, "hourly limit reached")
                return
            }
        }

        // find the Reply action (with RemoteInput)
        var act: Notification.Action? = null
        val acts = ArrayList<Notification.Action>()
        n.actions?.let { acts.addAll(it) }
        try {
            acts.addAll(Notification.WearableExtender(n).actions)
        } catch (e: Throwable) {
        }
        for (a in acts) {
            val ri = a.remoteInputs
            if (ri != null && ri.isNotEmpty()) {
                if (a.title?.toString()?.lowercase()?.contains("reply") == true) { act = a; break }
                if (act == null) act = a
            }
        }
        if (act == null) { L.add(c, title, text, "", "no Reply action in notification"); return }

        val finalAct: Notification.Action = act
        val grp = isGroup
        pool.execute {
            try {
                process(c, keyWho, title, text, grp, finalAct)
            } catch (e: Throwable) {
                L.add(c, title, text, "", "ERROR: " + e.message)
            }
        }
    }

    private fun matchRule(c: Context, text: String): String? {
        val low = text.lowercase()
        for (line in P.get(c, "rules").lines()) {
            val i = line.indexOf("=>")
            if (i <= 0) continue
            val rep = line.substring(i + 2).trim()
            if (rep.isEmpty()) continue
            for (kw in line.substring(0, i).split("|")) {
                val k = kw.trim().lowercase()
                if (k.isNotEmpty() && low.contains(k)) return rep
            }
        }
        return null
    }

    private fun process(c: Context, keyWho: String, who: String, text: String, isGroup: Boolean, act: Notification.Action) {
        val t0 = System.currentTimeMillis()
        val mode = P.int(c, "mode")
        val fixed = P.get(c, "fixedText").trim()
        var reply: String? = null
        var status = ""

        if (mode == 1) {
            reply = fixed
            status = "fixed text"
        } else {
            val rule = matchRule(c, text)
            if (rule != null) {
                reply = rule
                status = "keyword rule"
            } else if (mode == 0) {
                try {
                    val hist = if (P.on(c, "memOn")) Mem.load(c, who) else emptyList()
                    reply = Gemini.reply(c, text, who, isGroup, hist)
                    status = "AI"
                } catch (e: Exception) {
                    status = "AI error: " + e.message
                    if (P.on(c, "fallback") && fixed.isNotEmpty()) {
                        reply = fixed
                        status += " -> fixed text sent"
                    }
                }
            } else {
                if (P.on(c, "fallback") && fixed.isNotEmpty()) {
                    reply = fixed
                    status = "no rule matched -> fixed text"
                } else {
                    status = "no rule matched"
                }
            }
        }

        if (reply.isNullOrBlank()) {
            L.add(c, who, text, "", status)
            return
        }

        val replyText: String = reply.trim()
        val finalReply = P.get(c, "prefix") + replyText + P.get(c, "suffix")

        val dmin = P.int(c, "delayMin").coerceAtLeast(0)
        val dmax = maxOf(dmin, P.int(c, "delayMax"))
        val delayMs = (dmin + Random.nextInt(dmax - dmin + 1)) * 1000L
        val remain = delayMs - (System.currentTimeMillis() - t0)
        if (remain > 0) Thread.sleep(remain)

        val ris = act.remoteInputs
        if (ris == null || ris.isEmpty()) {
            L.add(c, who, text, finalReply, "no remote input")
            return
        }
        val intent = Intent()
        val bundle = Bundle()
        for (ri in ris) bundle.putCharSequence(ri.resultKey, finalReply)
        RemoteInput.addResultsToIntent(ris, intent, bundle)
        try {
            act.actionIntent.send(c, 0, intent)
        } catch (e: Exception) {
            L.add(c, who, text, finalReply, "SEND FAILED: " + e.message)
            return
        }

        synchronized(sentTexts) {
            sentTexts.add(finalReply)
            sentTexts.add(replyText)
            while (sentTexts.size > 40) sentTexts.removeAt(0)
        }
        val nowT = System.currentTimeMillis()
        lastReplyAt[keyWho] = nowT
        hourly.getOrPut(keyWho) { ArrayList() }.let { l -> synchronized(l) { l.add(nowT) } }
        if (P.on(c, "memOn")) {
            Mem.add(c, who, "user", text)
            Mem.add(c, who, "model", replyText)
        }
        L.add(c, who, text, finalReply, "SENT ($status)")
    }
}
